var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/home');

    $stateProvider
        
         // Home View
        .state('homePage', {
            url: '/homePage',
            templateUrl: 'templates/homePage.html'
        })
    
     // Home View
        .state('info', {
            url: '/info',
            templateUrl: 'templates/info.html'
        })
       
        .state('comosoy', {
            url: '/comosoy',
            templateUrl: 'templates/ComoSoy.html'
        })


        .state('mismetas', {
            url: '/mismetas',
            templateUrl: 'templates/MisMetas.html'
        });

});
